export const profile = {
  name: 'Peter Parker',
  shortName: 'Peter',
  role: 'Full-stack web developer and interface designer',
  location: 'Queens, New York',
  tagline: 'Your friendly neighborhood developer. I build fast, beautiful web apps that do the heavy lifting.',
  email: 'hello@peterparker.dev',
  bio: [
    'I started coding in my aunt\'s attic with a secondhand laptop and a stubborn idea: the web should feel alive. Eight years later I still chase that feeling, building interfaces that respond to people the way a good friend does.',
    'I work across the whole stack, from pixel-perfect layouts and motion design to databases, APIs, and the cloud services that keep everything running. I care most about the moment a product feels effortless.',
  ],
};

export const stats = [
  { value: 40, suffix: '+', label: 'Projects shipped' },
  { value: 8, suffix: ' yrs', label: 'Building for the web' },
  { value: 99.9, suffix: '%', label: 'Average uptime', decimals: 1 },
];

export interface Project {
  id: string;
  title: string;
  summary: string;
  details: string;
  tags: string[];
  image: string;
  imageAlt: string;
}

export const projects: Project[] = [
  {
    id: 'web-slinger',
    title: 'Web-Slinger Dashboard',
    summary: 'A real-time analytics dashboard that turns messy metrics into clear, live stories.',
    details:
      'Built for a logistics team that needed to watch thousands of deliveries at once. I designed a responsive grid of live charts, smart alerts, and drill-down views that load in under a second.',
    tags: ['React', 'TypeScript', 'Supabase'],
    image: 'https://images.pexels.com/photos/462267/pexels-photo-462267.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    imageAlt: 'New York City skyline lit up at night',
  },
  {
    id: 'daily-bugle',
    title: 'Daily Bugle CMS',
    summary: 'A publishing platform that takes a story from first draft to front page.',
    details:
      'A newsroom tool with role-based editing, scheduled publishing, and an editorial calendar. Writers stay in flow while editors get a clean review queue and version history.',
    tags: ['Node.js', 'PostgreSQL', 'Tailwind'],
    image: 'https://images.pexels.com/photos/5473309/pexels-photo-5473309.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    imageAlt: 'Woman working late on a laptop in a dark room',
  },
  {
    id: 'spider-sense',
    title: 'Spider-Sense Monitor',
    summary: 'Uptime monitoring that warns you before your users notice a problem.',
    details:
      'A status and health monitor with instant alerts, response-time history, and a public status page. Edge functions check endpoints around the world and report back within seconds.',
    tags: ['Vite', 'Edge Functions', 'Realtime'],
    image: 'https://images.pexels.com/photos/40081298/pexels-photo-40081298.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    imageAlt: 'New York City skyline at twilight',
  },
  {
    id: 'rooftop-booking',
    title: 'Rooftop Booking App',
    summary: 'A reservation experience for the city\'s best hidden rooftop venues.',
    details:
      'An interactive booking flow with live availability, seat maps, and mobile-first checkout. Designed with smooth transitions so every step feels like part of the view.',
    tags: ['React', 'Stripe', 'CSS Animation'],
    image: 'https://images.pexels.com/photos/19130909/pexels-photo-19130909.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    imageAlt: 'Rooftop skyline panorama at sunset',
  },
];

export interface Power {
  name: string;
  level: number;
}

export const powers: Power[] = [
  { name: 'React and TypeScript', level: 95 },
  { name: 'Interface design', level: 88 },
  { name: 'Node.js and APIs', level: 84 },
  { name: 'PostgreSQL and data modeling', level: 80 },
  { name: 'Motion and 3D on the web', level: 76 },
  { name: 'Performance tuning', level: 90 },
];

export const skillBadges = [
  'Accessibility',
  'Design systems',
  'Testing',
  'Edge computing',
  'Technical writing',
  'Mentoring',
];

export const navLinks = [
  { label: 'About', href: '#about' },
  { label: 'Missions', href: '#missions' },
  { label: 'Powers', href: '#powers' },
  { label: 'Contact', href: '#contact' },
];
