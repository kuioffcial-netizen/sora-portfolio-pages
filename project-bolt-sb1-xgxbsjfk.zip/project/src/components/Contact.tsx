import { useState, type FormEvent } from 'react';
import { AlertCircle, CheckCircle2, Loader2, Mail, MapPin, Send } from 'lucide-react';
import Reveal from '@/components/Reveal';
import { supabase } from '@/lib/supabase';
import { profile } from '@/data/portfolio';

type Status = 'idle' | 'sending' | 'success' | 'error';

interface FormValues {
  name: string;
  email: string;
  message: string;
}

const EMPTY_FORM: FormValues = { name: '', email: '', message: '' };
const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function validate(values: FormValues): Partial<Record<keyof FormValues, string>> {
  const errors: Partial<Record<keyof FormValues, string>> = {};
  if (!values.name.trim()) errors.name = 'Please tell me your name.';
  if (!EMAIL_PATTERN.test(values.email.trim())) errors.email = 'Please enter a valid email address.';
  if (!values.message.trim()) errors.message = 'Your message cannot be empty.';
  else if (values.message.trim().length > 2000) errors.message = 'Please keep your message under 2000 characters.';
  return errors;
}

const inputClass =
  'mt-2 w-full rounded-md border border-ink-600 bg-ink-950 px-4 py-3 text-ink-50 placeholder:text-ink-500 transition-colors focus:border-web-400 focus:outline-none focus:ring-2 focus:ring-web-500/30';

export default function Contact() {
  const [values, setValues] = useState<FormValues>(EMPTY_FORM);
  const [errors, setErrors] = useState<Partial<Record<keyof FormValues, string>>>({});
  const [status, setStatus] = useState<Status>('idle');

  const updateField = (field: keyof FormValues, value: string) => {
    setValues((prev) => ({ ...prev, [field]: value }));
    setErrors((prev) => ({ ...prev, [field]: undefined }));
  };

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const found = validate(values);
    setErrors(found);
    if (Object.keys(found).length > 0) return;

    setStatus('sending');
    const { error } = await supabase.from('contact_messages').insert({
      name: values.name.trim(),
      email: values.email.trim(),
      message: values.message.trim(),
    });

    if (error) {
      setStatus('error');
      return;
    }
    setValues(EMPTY_FORM);
    setStatus('success');
  };

  return (
    <section id="contact" className="relative mx-auto max-w-7xl px-6 py-32">
      <div className="grid gap-16 lg:grid-cols-[0.9fr_1.1fr] lg:gap-20">
        <Reveal>
          <p className="eyebrow">04 / Call me</p>
          <h2 className="section-title mt-4">START A MISSION</h2>
          <p className="mt-8 max-w-md text-lg leading-relaxed text-ink-300">
            Have a project that needs a hero? Tell me about it and I will get back to you within two business days.
          </p>
          <ul className="mt-10 space-y-5">
            <li className="flex items-center gap-4 text-ink-200">
              <span className="flex h-11 w-11 items-center justify-center rounded-md bg-web-900/60 text-web-300">
                <Mail className="h-5 w-5" />
              </span>
              <a href={`mailto:${profile.email}`} className="transition-colors hover:text-web-300">
                {profile.email}
              </a>
            </li>
            <li className="flex items-center gap-4 text-ink-200">
              <span className="flex h-11 w-11 items-center justify-center rounded-md bg-spider-900/60 text-spider-300">
                <MapPin className="h-5 w-5" />
              </span>
              {profile.location}
            </li>
          </ul>
        </Reveal>

        <Reveal delay={150}>
          {status === 'success' ? (
            <div
              role="status"
              className="flex h-full min-h-[420px] flex-col items-center justify-center rounded-2xl border border-emerald-500/40 bg-ink-900 p-10 text-center animate-fade-up"
            >
              <CheckCircle2 className="h-14 w-14 text-emerald-400" />
              <h3 className="mt-6 font-display text-4xl tracking-wide text-ink-50">Message received</h3>
              <p className="mt-3 max-w-sm text-ink-300">Thanks for reaching out. Your message is on its way to my inbox.</p>
              <button type="button" onClick={() => setStatus('idle')} className="btn-secondary mt-8">
                Send another message
              </button>
            </div>
          ) : (
            <form
              onSubmit={handleSubmit}
              noValidate
              className="space-y-6 rounded-2xl border border-ink-700 bg-ink-900/70 p-8 sm:p-10"
            >
              <div className="grid gap-6 sm:grid-cols-2">
                <div>
                  <label htmlFor="contact-name" className="text-sm font-medium text-ink-200">
                    Name
                  </label>
                  <input
                    id="contact-name"
                    type="text"
                    autoComplete="name"
                    value={values.name}
                    onChange={(event) => updateField('name', event.target.value)}
                    maxLength={100}
                    placeholder="Mary Jane"
                    aria-invalid={Boolean(errors.name)}
                    className={inputClass}
                  />
                  {errors.name && <p className="mt-2 text-sm text-spider-300">{errors.name}</p>}
                </div>
                <div>
                  <label htmlFor="contact-email" className="text-sm font-medium text-ink-200">
                    Email
                  </label>
                  <input
                    id="contact-email"
                    type="email"
                    autoComplete="email"
                    value={values.email}
                    onChange={(event) => updateField('email', event.target.value)}
                    maxLength={255}
                    placeholder="you@example.com"
                    aria-invalid={Boolean(errors.email)}
                    className={inputClass}
                  />
                  {errors.email && <p className="mt-2 text-sm text-spider-300">{errors.email}</p>}
                </div>
              </div>

              <div>
                <label htmlFor="contact-message" className="text-sm font-medium text-ink-200">
                  Message
                </label>
                <textarea
                  id="contact-message"
                  rows={6}
                  value={values.message}
                  onChange={(event) => updateField('message', event.target.value)}
                  maxLength={2000}
                  placeholder="Tell me about your project, timeline, and goals."
                  aria-invalid={Boolean(errors.message)}
                  className={`${inputClass} resize-none`}
                />
                <div className="mt-2 flex items-start justify-between gap-4">
                  {errors.message ? (
                    <p className="text-sm text-spider-300">{errors.message}</p>
                  ) : (
                    <span />
                  )}
                  <span className="shrink-0 text-xs tabular-nums text-ink-500">{values.message.length}/2000</span>
                </div>
              </div>

              {status === 'error' && (
                <div role="alert" className="flex items-start gap-3 rounded-md border border-spider-700 bg-spider-900/40 p-4 text-sm text-spider-100">
                  <AlertCircle className="mt-0.5 h-5 w-5 shrink-0 text-spider-300" />
                  <p>Something went wrong and your message was not sent. Please try again in a moment.</p>
                </div>
              )}

              <button
                type="submit"
                disabled={status === 'sending'}
                className="btn-primary w-full disabled:cursor-not-allowed disabled:opacity-70 sm:w-auto"
              >
                {status === 'sending' ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Sending
                  </>
                ) : (
                  <>
                    Send message
                    <Send className="h-4 w-4" />
                  </>
                )}
              </button>
            </form>
          )}
        </Reveal>
      </div>
    </section>
  );
}
