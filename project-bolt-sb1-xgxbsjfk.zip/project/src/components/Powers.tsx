import { useRef } from 'react';
import Reveal from '@/components/Reveal';
import { useInView } from '@/hooks/useInView';
import { powers, type Power } from '@/data/portfolio';

function PowerBar({ power }: { power: Power }) {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref);

  return (
    <div ref={ref}>
      <div className="flex items-center justify-between text-sm">
        <span className="font-medium text-ink-100">{power.name}</span>
        <span className="tabular-nums text-web-300">{power.level}%</span>
      </div>
      <div className="mt-3 h-2 overflow-hidden rounded-full bg-ink-800">
        <div
          className="h-full rounded-full bg-gradient-to-r from-web-500 to-spider-500 transition-[width] duration-1000 ease-out"
          style={{ width: inView ? `${power.level}%` : '0%' }}
        />
      </div>
    </div>
  );
}

export default function Powers() {
  return (
    <section id="powers" className="relative mx-auto max-w-7xl px-6 py-32">
      <div className="grid gap-16 lg:grid-cols-2 lg:gap-24">
        <Reveal>
          <p className="eyebrow">03 / Abilities</p>
          <h2 className="section-title mt-4">MY POWERS</h2>
          <p className="mt-8 max-w-lg text-lg leading-relaxed text-ink-300">
            Like a good spider-sense, I can usually tell where a project is headed before it gets there. These are the tools I reach for most.
          </p>
        </Reveal>

        <Reveal delay={150} className="space-y-8 rounded-2xl border border-ink-700 bg-ink-900/70 p-8 sm:p-10">
          {powers.map((power) => (
            <PowerBar key={power.name} power={power} />
          ))}
        </Reveal>
      </div>
    </section>
  );
}
