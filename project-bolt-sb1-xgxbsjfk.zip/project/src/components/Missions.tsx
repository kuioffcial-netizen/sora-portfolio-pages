import { useState } from 'react';
import { ArrowRight } from 'lucide-react';
import Reveal from '@/components/Reveal';
import ProjectModal from '@/components/ProjectModal';
import { projects, type Project } from '@/data/portfolio';

export default function Missions() {
  const [active, setActive] = useState<Project | null>(null);

  return (
    <section id="missions" className="relative border-y border-ink-800 bg-ink-900/40 py-32">
      <div className="mx-auto max-w-7xl px-6">
        <Reveal className="flex flex-col gap-6 md:flex-row md:items-end md:justify-between">
          <div>
            <p className="eyebrow">02 / Selected work</p>
            <h2 className="section-title mt-4">MY MISSIONS</h2>
          </div>
          <p className="max-w-md text-ink-300">
            A few recent projects where I swung in, solved the problem, and left the codebase cleaner than I found it.
          </p>
        </Reveal>

        <div className="mt-16 grid gap-8 md:grid-cols-2">
          {projects.map((project, index) => (
            <Reveal key={project.id} delay={(index % 2) * 120}>
              <button
                type="button"
                onClick={() => setActive(project)}
                className="group relative block w-full overflow-hidden rounded-2xl border border-ink-700 bg-ink-900 text-left transition-all duration-500 hover:-translate-y-2 hover:border-web-500/60 hover:shadow-2xl hover:shadow-web-900/40 focus-visible:outline focus-visible:outline-2 focus-visible:outline-web-300"
              >
                <div className="relative h-64 overflow-hidden">
                  <img
                    src={project.image}
                    alt={project.imageAlt}
                    loading="lazy"
                    className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-ink-900 via-ink-900/20 to-transparent" />
                  <span className="absolute left-5 top-5 rounded-md bg-spider-600 px-3 py-1 text-xs font-semibold tracking-wider text-ink-50">
                    MISSION {String(index + 1).padStart(2, '0')}
                  </span>
                </div>

                <div className="p-8">
                  <h3 className="font-display text-4xl tracking-wide text-ink-50">{project.title}</h3>
                  <p className="mt-3 leading-relaxed text-ink-300">{project.summary}</p>
                  <div className="mt-6 flex items-center justify-between gap-4">
                    <div className="flex flex-wrap gap-2">
                      {project.tags.map((tag) => (
                        <span key={tag} className="rounded-full bg-ink-800 px-3 py-1 text-xs font-medium text-ink-200">
                          {tag}
                        </span>
                      ))}
                    </div>
                    <span className="flex shrink-0 items-center gap-1 text-sm font-semibold text-web-300 transition-all duration-300 group-hover:gap-2 group-hover:text-web-200">
                      Case file
                      <ArrowRight className="h-4 w-4" />
                    </span>
                  </div>
                </div>
              </button>
            </Reveal>
          ))}
        </div>
      </div>

      {active && <ProjectModal project={active} onClose={() => setActive(null)} />}
    </section>
  );
}
