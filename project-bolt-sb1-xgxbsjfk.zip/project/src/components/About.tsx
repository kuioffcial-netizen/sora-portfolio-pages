import Reveal from '@/components/Reveal';
import CountUp from '@/components/CountUp';
import { profile, skillBadges, stats } from '@/data/portfolio';

export default function About() {
  return (
    <section id="about" className="relative mx-auto max-w-7xl px-6 py-32">
      <div className="grid gap-16 lg:grid-cols-[1fr_1.1fr] lg:gap-20">
        <Reveal>
          <p className="eyebrow">01 / Origin story</p>
          <h2 className="section-title mt-4">WHO I AM</h2>
          <div className="mt-8 space-y-5 text-lg leading-relaxed text-ink-300">
            {profile.bio.map((paragraph) => (
              <p key={paragraph.slice(0, 24)}>{paragraph}</p>
            ))}
          </div>
          <div className="mt-10 flex flex-wrap gap-2">
            {skillBadges.map((badge) => (
              <span
                key={badge}
                className="rounded-full border border-ink-600 bg-ink-900 px-4 py-1.5 text-sm text-ink-200 transition-colors hover:border-web-400 hover:text-web-200"
              >
                {badge}
              </span>
            ))}
          </div>
        </Reveal>

        <div className="grid content-start gap-5 sm:grid-cols-3 lg:grid-cols-1">
          {stats.map((stat, index) => (
            <Reveal key={stat.label} delay={index * 120}>
              <div className="group relative overflow-hidden rounded-2xl border border-ink-700 bg-ink-900/70 p-8 transition-all duration-500 hover:-translate-y-1 hover:border-spider-600/60">
                <div
                  aria-hidden
                  className="absolute -right-10 -top-10 h-32 w-32 rounded-full bg-spider-600/10 blur-2xl transition-all duration-500 group-hover:scale-150 group-hover:bg-spider-600/20"
                />
                <p className="relative font-display text-6xl text-ink-50 sm:text-7xl">
                  <CountUp value={stat.value} suffix={stat.suffix} decimals={stat.decimals ?? 0} />
                </p>
                <p className="relative mt-2 text-sm font-medium uppercase tracking-wider text-ink-400">{stat.label}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
