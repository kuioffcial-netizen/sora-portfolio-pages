import { Webhook } from 'lucide-react';
import { navLinks, profile } from '@/data/portfolio';

export default function Footer() {
  return (
    <footer className="border-t border-ink-800 bg-ink-950">
      <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-6 px-6 py-10 md:flex-row">
        <a href="#top" className="flex items-center gap-3">
          <span className="flex h-8 w-8 items-center justify-center rounded-md bg-spider-600 text-ink-50">
            <Webhook className="h-4 w-4" />
          </span>
          <span className="font-display text-xl tracking-wider text-ink-50">{profile.name.toUpperCase()}</span>
        </a>
        <ul className="flex flex-wrap justify-center gap-6">
          {navLinks.map((link) => (
            <li key={link.href}>
              <a href={link.href} className="text-sm text-ink-400 transition-colors hover:text-web-300">
                {link.label}
              </a>
            </li>
          ))}
        </ul>
        <p className="text-sm text-ink-500">© {new Date().getFullYear()} {profile.name}. Built with web-slinging care.</p>
      </div>
    </footer>
  );
}
