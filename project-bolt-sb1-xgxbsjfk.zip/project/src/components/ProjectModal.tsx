import { useEffect } from 'react';
import { X } from 'lucide-react';
import type { Project } from '@/data/portfolio';

interface ProjectModalProps {
  project: Project;
  onClose: () => void;
}

export default function ProjectModal({ project, onClose }: ProjectModalProps) {
  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') onClose();
    };
    document.body.style.overflow = 'hidden';
    window.addEventListener('keydown', onKeyDown);
    return () => {
      document.body.style.overflow = '';
      window.removeEventListener('keydown', onKeyDown);
    };
  }, [onClose]);

  return (
    <div
      className="fixed inset-0 z-[70] flex items-center justify-center bg-ink-950/80 p-4 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="project-modal-title"
        onClick={(event) => event.stopPropagation()}
        className="relative w-full max-w-2xl overflow-hidden rounded-2xl border border-ink-700 bg-ink-900 shadow-2xl animate-fade-up"
      >
        <div className="relative h-56 sm:h-72">
          <img src={project.image} alt={project.imageAlt} className="h-full w-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-ink-900 via-ink-900/30 to-transparent" />
        </div>
        <button
          type="button"
          onClick={onClose}
          aria-label="Close project details"
          className="absolute right-4 top-4 rounded-full bg-ink-950/70 p-2 text-ink-50 transition-colors hover:bg-spider-600"
        >
          <X className="h-5 w-5" />
        </button>

        <div className="p-8">
          <p className="eyebrow">Case file</p>
          <h3 id="project-modal-title" className="mt-3 font-display text-4xl tracking-wide text-ink-50">
            {project.title}
          </h3>
          <p className="mt-4 leading-relaxed text-ink-300">{project.details}</p>
          <div className="mt-6 flex flex-wrap gap-2">
            {project.tags.map((tag) => (
              <span key={tag} className="rounded-full bg-web-900/60 px-3 py-1 text-xs font-medium text-web-200">
                {tag}
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
