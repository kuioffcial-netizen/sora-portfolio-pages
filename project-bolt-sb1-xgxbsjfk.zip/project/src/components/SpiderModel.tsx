import { useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { CatmullRomCurve3, Group, TubeGeometry, Vector3 } from 'three';

const LEG_ROOTS = [0.42, 0.12, -0.2, -0.5];

function buildLegCurve(side: 1 | -1, z: number) {
  return new CatmullRomCurve3([
    new Vector3(side * 0.3, 0, z),
    new Vector3(side * 0.95, 0.45, z + 0.12),
    new Vector3(side * 1.55, 0.8, z + 0.3),
    new Vector3(side * 1.9, -0.05, z + 0.45),
    new Vector3(side * 1.95, -1.0, z + 0.5),
  ]);
}

interface SpiderLegProps {
  side: 1 | -1;
  z: number;
  phase: number;
}

function SpiderLeg({ side, z, phase }: SpiderLegProps) {
  const groupRef = useRef<Group>(null);

  const { tube, knee } = useMemo(() => {
    const curve = buildLegCurve(side, z);
    return {
      tube: new TubeGeometry(curve, 48, 0.055, 12, false),
      knee: curve.getPoint(0.42),
    };
  }, [side, z]);

  useFrame(({ clock }) => {
    if (!groupRef.current) return;
    groupRef.current.rotation.y = Math.sin(clock.getElapsedTime() * 2.4 + phase) * 0.12;
  });

  return (
    <group ref={groupRef}>
      <mesh geometry={tube}>
        <meshStandardMaterial color="#1a41ad" metalness={0.45} roughness={0.3} />
      </mesh>
      <mesh position={knee}>
        <sphereGeometry args={[0.09, 20, 20]} />
        <meshStandardMaterial color="#d91a22" metalness={0.3} roughness={0.35} />
      </mesh>
    </group>
  );
}

export default function SpiderModel() {
  const groupRef = useRef<Group>(null);

  useFrame((state) => {
    const group = groupRef.current;
    if (!group) return;

    const t = state.clock.getElapsedTime();
    const scrollProgress = Math.min(window.scrollY / window.innerHeight, 1.5);
    const targetY = scrollProgress * Math.PI * 0.9 + state.pointer.x * 0.35;
    const targetX = -0.12 + state.pointer.y * 0.2;

    group.rotation.y += (targetY - group.rotation.y) * 0.08;
    group.rotation.x += (targetX - group.rotation.x) * 0.08;
    group.position.y = Math.sin(t * 1.2) * 0.12;
  });

  return (
    <group ref={groupRef}>
      <mesh position={[0, 0, -0.75]} scale={[0.9, 1.1, 1.2]}>
        <sphereGeometry args={[0.62, 48, 48]} />
        <meshStandardMaterial color="#d91a22" metalness={0.35} roughness={0.35} />
      </mesh>
      <mesh position={[0, 0.62, -0.75]} scale={[0.28, 0.42, 0.18]}>
        <sphereGeometry args={[1, 24, 24]} />
        <meshStandardMaterial color="#0c0e14" roughness={0.5} />
      </mesh>

      <mesh position={[0, 0.05, 0.4]} scale={[1, 0.85, 1.05]}>
        <sphereGeometry args={[0.52, 48, 48]} />
        <meshStandardMaterial color="#1d52d6" metalness={0.4} roughness={0.3} />
      </mesh>

      {[-0.2, 0.2].map((x) => (
        <mesh key={x} position={[x, 0.2, 0.84]} scale={[1.2, 0.7, 0.5]}>
          <sphereGeometry args={[0.2, 32, 32]} />
          <meshStandardMaterial color="#f8fafc" emissive="#ffffff" emissiveIntensity={0.15} roughness={0.15} metalness={0.2} />
        </mesh>
      ))}

      {LEG_ROOTS.map((z, index) =>
        ([1, -1] as const).map((side) => (
          <SpiderLeg
            key={`${side}-${index}`}
            side={side}
            z={z}
            phase={index * 0.9 + (side === 1 ? 0 : Math.PI)}
          />
        )),
      )}
    </group>
  );
}
