import { Canvas } from '@react-three/fiber';
import { ArrowDown } from 'lucide-react';
import SpiderModel from '@/components/SpiderModel';
import { profile } from '@/data/portfolio';

export default function Hero() {
  return (
    <section id="top" className="relative overflow-hidden web-grid">
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 bg-gradient-to-b from-ink-950 via-transparent to-ink-950"
      />
      <div className="relative mx-auto grid min-h-screen max-w-7xl items-center gap-4 px-6 pb-20 pt-28 lg:grid-cols-2 lg:gap-0">
        <div className="order-2 lg:order-1">
          <p className="eyebrow animate-fade-up">{profile.location}</p>
          <h1
            className="mt-4 font-display text-7xl leading-[0.92] text-ink-50 animate-fade-up sm:text-8xl lg:text-[9rem]"
            style={{ animationDelay: '120ms' }}
          >
            PETER
            <br />
            <span className="text-spider-500">PARKER</span>
          </h1>
          <p
            className="mt-6 text-lg font-medium text-web-300 animate-fade-up"
            style={{ animationDelay: '240ms' }}
          >
            {profile.role}
          </p>
          <p
            className="mt-4 max-w-xl text-base leading-relaxed text-ink-300 animate-fade-up sm:text-lg"
            style={{ animationDelay: '360ms' }}
          >
            {profile.tagline}
          </p>
          <div className="mt-10 flex flex-wrap gap-4 animate-fade-up" style={{ animationDelay: '480ms' }}>
            <a href="#missions" className="btn-primary">
              View my missions
            </a>
            <a href="#contact" className="btn-secondary">
              Say hello
            </a>
          </div>
        </div>

        <div className="relative order-1 h-[52vh] lg:order-2 lg:h-[78vh]">
          <div aria-hidden className="absolute inset-[10%] rounded-full bg-spider-600/20 blur-3xl" />
          <Canvas camera={{ position: [0, 0.4, 7], fov: 45 }} dpr={[1, 2]}>
            <ambientLight intensity={0.6} />
            <directionalLight position={[4, 6, 5]} intensity={1.4} />
            <pointLight position={[-3, 0, 3]} color="#f7262f" intensity={8} distance={10} />
            <pointLight position={[3, -1, 2]} color="#5b8dfb" intensity={6} distance={10} />
            <SpiderModel />
          </Canvas>
        </div>
      </div>

      <a
        href="#about"
        aria-label="Scroll to about section"
        className="absolute bottom-8 left-1/2 hidden -translate-x-1/2 flex-col items-center gap-2 text-xs uppercase tracking-[0.25em] text-ink-400 transition-colors hover:text-web-300 md:flex"
      >
        Scroll
        <ArrowDown className="h-5 w-5 animate-float-slow" />
      </a>
    </section>
  );
}
