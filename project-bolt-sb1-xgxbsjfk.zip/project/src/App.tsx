import Navbar from '@/components/Navbar';
import ScrollProgress from '@/components/ScrollProgress';
import Hero from '@/components/Hero';
import About from '@/components/About';
import Missions from '@/components/Missions';
import Powers from '@/components/Powers';
import Contact from '@/components/Contact';
import Footer from '@/components/Footer';

function App() {
  return (
    <div className="min-h-screen bg-ink-950 text-ink-100">
      <ScrollProgress />
      <Navbar />
      <main>
        <Hero />
        <About />
        <Missions />
        <Powers />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}

export default App;
