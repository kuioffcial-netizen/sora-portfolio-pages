/*
# Create contact messages table

1. New Tables
- `contact_messages`
  - `id` (uuid, primary key)
  - `name` (text, required, up to 100 characters)
  - `email` (text, required, up to 255 characters)
  - `message` (text, required, up to 2000 characters)
  - `created_at` (timestamptz, defaults to now)

2. Security
- Enable RLS on `contact_messages`.
- Grant INSERT only to `anon` and `authenticated` so visitors can send messages.
- Only an INSERT policy is added; visitors cannot read, change, or delete messages.
*/

CREATE TABLE IF NOT EXISTS contact_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL CHECK (char_length(name) BETWEEN 1 AND 100),
  email text NOT NULL CHECK (char_length(email) BETWEEN 3 AND 255),
  message text NOT NULL CHECK (char_length(message) BETWEEN 1 AND 2000),
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE contact_messages ENABLE ROW LEVEL SECURITY;

GRANT INSERT ON contact_messages TO anon, authenticated;

DROP POLICY IF EXISTS "anon_insert_contact_messages" ON contact_messages;
CREATE POLICY "anon_insert_contact_messages" ON contact_messages FOR INSERT
TO anon, authenticated
WITH CHECK (true);
